<?php

namespace App;

use App\Traits\Uuid;
use Illuminate\Database\Eloquent\Model;

class Jawaban_peserta extends Model
{
    use Uuid;
}
